morgan_sim.csv consists of morgan similarities where test compounds are compared to themselves and a number of other known odorants 
first column and row are the CIDs of the odorants

